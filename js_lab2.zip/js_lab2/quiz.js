function Quiz(listOfQuestions) {
   this.questionIndex=0;
   this.listOfQuestions=listOfQuestions;
   this.score=0;
}

function Question(text, choices, answer) {
  this.questionText=text;
  this.choices=choices;
  this.answer=answer;  
}
Quiz.prototype.isEnded = function() {
 return this.questionIndex==this.listOfQuestions.length?true:false;
}

Quiz.prototype.checkOptionWithAnswer = function(answer) {
   let questionEle=this.getQuestionByIndex();
    if(questionEle.isCorrectAnswer(answer))
        this.score++;
}

Quiz.prototype.getScore=function(){
    return this.score;
}
Quiz.prototype.nextQuestion=function(){
    this.questionIndex++;
}

Quiz.prototype.getQuestionByIndex = function() {
    return quiz.listOfQuestions[quiz.questionIndex]; 
}
Question.prototype.isCorrectAnswer = function(choice) {
    return choice==this.answer;
}
function showProgress() {
let progressElement=document.getElementById("progress");
progressElement.innerHTML=`Question ${quiz.questionIndex+1} of ${quiz.listOfQuestions.length}`;
}

function showScores() {
   let score=quiz.getScore();
   totalScore=quiz.listOfQuestions.length;
   document.querySelector('h1').innerText='Result';
   document.querySelector('#question').innerText=`Your score:${score} and mark percentage is ${(score/totalScore)*100}%`;
   document.querySelector('.buttons').style.visibility="hidden";
   const hrElement= document.querySelectorAll('hr');
   hrElement[1].style.visibility="hidden";
   document.querySelector('footer').style.visibility="hidden";
}
function handleBtnClick(id, choice) {
    const btn=document.getElementById(id);
    btn.onclick=function(){
       if(!quiz.isEnded()){
        quiz.checkOptionWithAnswer(choice);
        quiz.nextQuestion();
        loadQuestions();
       }
    }
}
function loadQuestions() {
 if(quiz.isEnded())
    showScores();
else{
    console.log(quiz.questionIndex);
    let questionObj=quiz.getQuestionByIndex(); 
    let question=questionObj.questionText;
    let choices=questionObj.choices;
    let qElement=document.getElementById("question");
    qElement.innerHTML=question;
    for(var i=0;i<choices.length;i++){
        let btnElement=document.getElementById("btn"+i);
         btnElement.innerHTML=choices[i];
         handleBtnClick(`btn${i}`,choices[i]);
    }
    showProgress();
}

}


let questionsList = [
new Question("Javascript supports ", ["Functions", "XHTML", "CSS", "HTML"], "Functions"),
new Question("Which Language used for Styling web pages ", ["HTML", "JQuery", "CSS", "XML"], "CSS"),
new Question("Which is not a JS Framework ", ["Angular", "JQuery", "Django", "NodeJS"], "Django"),
new Question("Which is used to connect DB ", ["PHP", "HTML", "JS", "All"], "PHP"),
new Question("Javascript is a ", ["Language", "Programming Language", "Development", "All"], "Programming Language")
]

let quiz = new Quiz(questionsList)


loadQuestions();